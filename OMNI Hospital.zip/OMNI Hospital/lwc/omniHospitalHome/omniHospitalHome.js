import { LightningElement } from 'lwc';

export default class OmniHospitalHome extends LightningElement {}